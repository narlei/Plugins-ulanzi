let setting = {
  bridgeUrl: "http://127.0.0.1:18181",
  removeSoundIndex: ""
};
let form = null;

$UD.connect("com.caios.ulanzideck.soundpad.remove");

$UD.onConnected(() => {
  form = document.querySelector("#property-inspector");
  document.querySelector(".udpi-wrapper").classList.remove("hidden");

  form.addEventListener(
    "input",
    Utils.debounce(() => {
      setting = { ...setting, ...Utils.getFormValue(form) };
      $UD.sendParamFromPlugin(setting);
    }, 250)
  );
});

function mergeSettings(jsonObj) {
  if (!jsonObj || !jsonObj.param) return;
  setting = { ...setting, ...jsonObj.param };
  Utils.setFormValue(setting, form);
}

$UD.onAdd(mergeSettings);
$UD.onParamFromApp(mergeSettings);
