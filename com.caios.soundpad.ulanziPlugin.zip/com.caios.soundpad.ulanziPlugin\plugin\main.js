import { spawn } from "child_process";
import { fileURLToPath } from "url";
import path from "path";
import http from "http";

import UlanzideckApi from "../libs/node/ulanzideckApi.js";

const APP_ID = "com.caios.ulanzideck.soundpad";
const $UD = new UlanzideckApi();

const ACTIONS = new Map();
let bridgeLaunchAttempted = false;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const BRIDGE_SCRIPT = path.resolve(__dirname, "../helper/bridge.ps1");

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function httpJson(method, url, payload) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const data = payload ? JSON.stringify(payload) : "";
    const req = http.request(
      {
        method,
        hostname: u.hostname,
        port: u.port,
        path: u.pathname + u.search,
        headers: {
          "Content-Type": "application/json",
          "Content-Length": Buffer.byteLength(data),
        },
      },
      (res) => {
        let raw = "";
        res.on("data", (chunk) => {
          raw += chunk.toString("utf8");
        });
        res.on("end", () => {
          try {
            const parsed = raw ? JSON.parse(raw) : {};
            resolve({ ok: res.statusCode >= 200 && res.statusCode < 300, status: res.statusCode, data: parsed });
          } catch (e) {
            reject(e);
          }
        });
      }
    );

    req.on("error", reject);
    if (data) req.write(data);
    req.end();
  });
}

async function ensureBridgeOnline(baseUrl) {
  try {
    const res = await httpJson("GET", `${baseUrl}/health`);
    if (res.ok) return true;
  } catch (_e) {}

  if (!bridgeLaunchAttempted) {
    bridgeLaunchAttempted = true;
    try {
      const child = spawn(
        "powershell.exe",
        ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", BRIDGE_SCRIPT],
        { detached: true, windowsHide: true, stdio: "ignore" }
      );
      child.unref();
    } catch (_e) {}
  }

  await delay(1200);
  try {
    const res = await httpJson("GET", `${baseUrl}/health`);
    return res.ok;
  } catch (_e) {
    return false;
  }
}

function getBase(settings) {
  return String(settings.bridgeUrl || "http://127.0.0.1:18181").replace(/\/$/, "");
}

function mergeSettings(context, next) {
  const curr = ACTIONS.get(context) || {};
  const merged = { ...curr, ...next };
  ACTIONS.set(context, merged);
  return merged;
}

function normalizeCategories(categories) {
  return (categories || []).map((c) => ({
    categoryName: c.Name,
    categoryIndex: c.Index,
  }));
}

function normalizeSounds(sounds) {
  return (sounds || []).map((s) => ({
    soundName: s.Title,
    soundIndex: s.Index,
  }));
}

async function refreshInspector(context, state) {
  const base = getBase(state);
  const online = await ensureBridgeOnline(base);
  if (!online) return;

  let categories = [];
  let sounds = [];

  const cat = await httpJson("GET", `${base}/categories`);
  if (cat.ok && cat.data?.ok) {
    categories = normalizeCategories(cat.data.categories);
  }

  if (String(state.actionid || "").endsWith(".play") && state.categoryIndex !== "" && state.categoryIndex !== undefined) {
    const snd = await httpJson("GET", `${base}/sounds?categoryIndex=${encodeURIComponent(String(state.categoryIndex))}`);
    if (snd.ok && snd.data?.ok) {
      sounds = normalizeSounds(snd.data.sounds);
    }
  }

  const outgoing = { ...state, categories, sounds };
  delete outgoing.property_inspector;
  $UD.sendParamFromPlugin(outgoing, context);
}

async function handleRun(data) {
  const context = data.context;
  const state = ACTIONS.get(context) || {};
  const base = getBase(state);
  const online = await ensureBridgeOnline(base);
  if (!online) return;

  const actionid = String(data.actionid || state.actionid || "");

  if (actionid.endsWith(".play")) {
    const index = Number(state.soundIndex);
    if (!Number.isFinite(index)) return;
    await httpJson("POST", `${base}/play`, { index });
    return;
  }
  if (actionid.endsWith(".playrandom")) {
    const categoryIndex = state.categoryIndex === "" ? null : Number(state.categoryIndex);
    await httpJson("POST", `${base}/play-random`, { categoryIndex });
    return;
  }
  if (actionid.endsWith(".pause")) {
    await httpJson("POST", `${base}/toggle-pause`, {});
    return;
  }
  if (actionid.endsWith(".stop")) {
    await httpJson("POST", `${base}/stop`, {});
    return;
  }
  if (actionid.endsWith(".remove")) {
    const index = Number(state.removeSoundIndex);
    if (!Number.isFinite(index)) return;
    await httpJson("POST", `${base}/remove`, { index });
    return;
  }
  if (actionid.endsWith(".recordptt")) {
    await httpJson("POST", `${base}/toggle-recording`, {});
    return;
  }
  if (actionid.endsWith(".loadsoundlist")) {
    const p = String(state.soundListFileName || "");
    if (!p) return;
    await httpJson("POST", `${base}/load-soundlist`, { path: p });
  }
}

$UD.connect(APP_ID);

$UD.onConnected(async () => {
  await ensureBridgeOnline("http://127.0.0.1:18181");
});

$UD.onAdd(async (data) => {
  mergeSettings(data.context, { ...(data.param || {}), actionid: data.actionid });
});

$UD.onSetActive((data) => {
  mergeSettings(data.context, { active: data.active });
});

$UD.onRun((data) => {
  handleRun(data).catch(() => {});
});

$UD.onClear((data) => {
  (data.param || []).forEach((p) => {
    if (p?.context) ACTIONS.delete(p.context);
  });
});

function onSettings(data) {
  const merged = mergeSettings(data.context, data.param || {});
  if (merged.property_inspector === "refreshSounds") {
    refreshInspector(data.context, merged).catch(() => {});
  }
}

$UD.onParamFromApp(onSettings);
$UD.onParamFromPlugin(onSettings);
