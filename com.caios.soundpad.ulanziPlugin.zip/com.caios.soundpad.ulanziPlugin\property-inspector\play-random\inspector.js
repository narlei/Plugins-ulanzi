let actionSetting = {
  categoryIndex: ""
};
let categories = [];
let form = null;

$UD.connect("com.caios.ulanzideck.soundpad.playrandom");

function render() {
  const el = document.getElementById("categoryIndex");
  el.innerHTML = "";
  const any = document.createElement("option");
  any.value = "";
  any.textContent = "(Any category)";
  el.appendChild(any);

  (categories || []).forEach((c) => {
    const op = document.createElement("option");
    op.value = String(c.categoryIndex);
    op.textContent = String(c.categoryName);
    el.appendChild(op);
  });
  el.value = String(actionSetting.categoryIndex || "");
}

function sendSettings(extra) {
  actionSetting.categoryIndex = document.getElementById("categoryIndex").value;
  $UD.sendParamFromPlugin({ ...actionSetting, ...(extra || {}) });
}

function requestRefresh() {
  $UD.sendParamFromPlugin({ ...actionSetting, property_inspector: "refreshSounds" });
}

$UD.onConnected(() => {
  form = document.querySelector("#property-inspector");
  document.querySelector(".udpi-wrapper").classList.remove("hidden");
  form.addEventListener("input", Utils.debounce(() => sendSettings(), 200));
  document.getElementById("refreshBtn").addEventListener("click", requestRefresh);
  requestRefresh();
});

function mergeSettings(jsonObj) {
  if (!jsonObj || !jsonObj.param) return;
  actionSetting = { ...actionSetting, ...jsonObj.param };
  categories = Array.isArray(jsonObj.param.categories) ? jsonObj.param.categories : categories;
  render();
}

$UD.onAdd((jsonObj) => {
  mergeSettings(jsonObj);
  requestRefresh();
});
$UD.onParamFromApp(mergeSettings);
