let actionSetting = {
  categoryIndex: "",
  soundIndex: "",
  showSoundTitle: false,
  pushToPlay: false
};
let categories = [];
let sounds = [];
let form = null;

$UD.connect("com.caios.ulanzideck.soundpad.play");

function toBool(v) {
  return v === true || v === "true" || v === "1" || v === 1;
}

function fillCategorySelect() {
  const el = document.getElementById("categoryIndex");
  el.innerHTML = "";
  const any = document.createElement("option");
  any.value = "";
  any.textContent = "(All categories)";
  el.appendChild(any);

  (categories || []).forEach((c) => {
    const op = document.createElement("option");
    op.value = String(c.categoryIndex);
    op.textContent = String(c.categoryName);
    el.appendChild(op);
  });

  if (actionSetting.categoryIndex !== undefined && actionSetting.categoryIndex !== null) {
    el.value = String(actionSetting.categoryIndex);
  }
}

function fillSoundSelect() {
  const el = document.getElementById("soundIndex");
  el.innerHTML = "";
  const any = document.createElement("option");
  any.value = "";
  any.textContent = "(Select sound)";
  el.appendChild(any);

  (sounds || []).forEach((s) => {
    const op = document.createElement("option");
    op.value = String(s.soundIndex);
    op.textContent = String(s.soundName);
    el.appendChild(op);
  });

  if (actionSetting.soundIndex !== undefined && actionSetting.soundIndex !== null) {
    el.value = String(actionSetting.soundIndex);
  }
}

function render() {
  fillCategorySelect();
  fillSoundSelect();
  document.getElementById("showSoundTitle").checked = toBool(actionSetting.showSoundTitle);
  document.getElementById("pushToPlay").checked = toBool(actionSetting.pushToPlay);
  document.getElementById("manualSoundIndex").value =
    actionSetting.soundIndexManual || "";
}

function sendSettings(extra) {
  const payload = {
    categoryIndex: document.getElementById("categoryIndex").value,
    soundIndex: document.getElementById("soundIndex").value,
    soundIndexManual: document.getElementById("manualSoundIndex").value,
    showSoundTitle: document.getElementById("showSoundTitle").checked,
    pushToPlay: document.getElementById("pushToPlay").checked
  };

  // If manual index is set, it should override dropdown choice.
  if (payload.soundIndexManual && payload.soundIndexManual.trim() !== "") {
    payload.soundIndex = payload.soundIndexManual.trim();
  }

  actionSetting = { ...actionSetting, ...payload };
  $UD.sendParamFromPlugin({ ...actionSetting, ...(extra || {}) });
}

function requestRefresh() {
  $UD.sendParamFromPlugin({ ...actionSetting, property_inspector: "refreshSounds" });
}

$UD.onConnected(() => {
  form = document.querySelector("#property-inspector");
  document.querySelector(".udpi-wrapper").classList.remove("hidden");

  form.addEventListener(
    "input",
    Utils.debounce(() => {
      sendSettings();
      if (document.activeElement && document.activeElement.id === "categoryIndex") {
        requestRefresh();
      }
    }, 200)
  );

  document.getElementById("refreshBtn").addEventListener("click", () => requestRefresh());
  requestRefresh();
});

function mergeSettings(jsonObj) {
  if (!jsonObj || !jsonObj.param) return;
  actionSetting = { ...actionSetting, ...jsonObj.param };
  categories = Array.isArray(jsonObj.param.categories) ? jsonObj.param.categories : categories;
  sounds = Array.isArray(jsonObj.param.sounds) ? jsonObj.param.sounds : sounds;
  render();
}

$UD.onAdd((jsonObj) => {
  mergeSettings(jsonObj);
  requestRefresh();
});

$UD.onParamFromApp((jsonObj) => {
  mergeSettings(jsonObj);
});
